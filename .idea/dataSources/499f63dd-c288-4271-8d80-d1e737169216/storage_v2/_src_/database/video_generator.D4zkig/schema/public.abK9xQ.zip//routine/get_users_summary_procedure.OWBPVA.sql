create procedure get_users_summary_procedure(OUT total_users integer, OUT user_list json)
    language plpgsql
as
$$
BEGIN
    -- Подсчет общего количества пользователей
    SELECT COUNT(*) INTO total_users FROM users;

    -- Формирование списка всех пользователей в формате JSON
    SELECT json_agg(json_build_object('id', id, 'name', name)) INTO user_list
    FROM users;
END;
$$;

alter procedure get_users_summary_procedure(out integer, out json) owner to root;


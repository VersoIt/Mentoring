create function log_video_insert() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO video_logs (log_message)
    VALUES (format('New video added: ID=%s, Title=%s', NEW.id, NEW.title));
    RETURN NEW;
END;
$$;

alter function log_video_insert() owner to root;


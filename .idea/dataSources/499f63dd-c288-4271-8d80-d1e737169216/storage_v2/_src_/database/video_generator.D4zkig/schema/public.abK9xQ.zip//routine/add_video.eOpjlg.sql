create procedure add_video(IN video_name text, IN video_url text)
    language plpgsql
as
$$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM videos WHERE url = video_url) THEN
        INSERT INTO videos (title, url) VALUES (title, video_url);
    ELSE
        RAISE NOTICE 'Video with this URL already exists.';
    END IF;
END;
$$;

alter procedure add_video(text, text) owner to root;


create procedure delete_video(IN video_id integer)
    language plpgsql
as
$$
BEGIN
    IF EXISTS (SELECT 1 FROM videos WHERE id = video_id) THEN
        DELETE FROM videos WHERE id = video_id;
    ELSE
        RAISE NOTICE 'Video with this ID does not exist.';
    END IF;
END;
$$;

alter procedure delete_video(integer) owner to root;


create function users_count() returns integer
    language plpgsql
as
$$
DECLARE
    user_count INT;
BEGIN
    -- Подсчет общего количества пользователей
    SELECT COUNT(*) INTO user_count FROM users;
    
    -- Возвращаем результат
    RETURN user_count;
END;
$$;

alter function users_count() owner to root;


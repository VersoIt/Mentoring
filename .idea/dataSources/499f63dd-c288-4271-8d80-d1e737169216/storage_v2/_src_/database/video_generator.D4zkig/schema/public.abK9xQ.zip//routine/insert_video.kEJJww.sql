create procedure insert_video(IN video_name text, IN video_url text)
    language plpgsql
as
$$
BEGIN
    -- Проверяем, существует ли уже видео с таким URL
    IF NOT EXISTS (SELECT 1 FROM videos WHERE url = video_url) THEN
        -- Если не существует, вставляем запись в таблицу
        INSERT INTO videos (title, url) VALUES (video_name, video_url);
        RAISE NOTICE 'Video "%" with URL "%" has been added.', video_name, video_url;
    ELSE
        -- Если видео с таким URL уже существует, выводим сообщение
        RAISE NOTICE 'Video with URL "%" already exists.', video_url;
    END IF;
END;
$$;

alter procedure insert_video(text, text) owner to root;


create function check_video_exists() returns trigger
    language plpgsql
as
$$
BEGIN
    IF is_video_exist(NEW.url) THEN
        RAISE NOTICE 'Video already exists with URL: %', NEW.url;
        RETURN NULL;
    ELSE
        RETURN NEW; 
    END IF;
END;
$$;

alter function check_video_exists() owner to root;


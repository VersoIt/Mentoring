create function is_video_exist(video_url text) returns boolean
    language plpgsql
as
$$
BEGIN
    RETURN EXISTS (SELECT 1 FROM videos WHERE url = video_url);
END;
$$;

alter function is_video_exist(text) owner to root;


create function set_default_name() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Если поле name NULL или пустое, установить 'UNKNOWN'
    IF NEW.name IS NULL OR NEW.name = '' THEN
        NEW.name := 'UNKNOWN';
    END IF;
    RETURN NEW;
END;
$$;

alter function set_default_name() owner to root;


create function update_video_name() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.name := 'Video: ' || NEW.name;
    RETURN NEW;
END;
$$;

alter function update_video_name() owner to root;


create view users_who_watched_all_videos(user_id, user_name) as
SELECT id   AS user_id,
       name AS user_name
FROM users u
WHERE NOT (EXISTS (SELECT 1
                   FROM videos v
                   WHERE NOT (EXISTS (SELECT 1
                                      FROM users_videos uv
                                      WHERE uv.user_id = u.id
                                        AND uv.video_id = v.id))));

alter table users_who_watched_all_videos
    owner to root;

